#include <stdlib.h>
#include <stdio.h>
#include "proto.h"
#include "mpi.h"
